Action()
{

	web_url("index.htm", 
		"URL=http://127.0.0.1:1080/WebTours/index.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("TicketPurchase_01_LogIn");

	lr_save_string(lr_decrypt("6089692213138abd"), "PasswordParameter");

	lr_think_time(6);

	web_submit_data("login.pl", 
		"Action=http://127.0.0.1:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value=131196.227055488zHtitAfpQcQVzzzHtAtQAptDffHf", ENDITEM, 
		"Name=username", "Value=jojo", ENDITEM, 
		"Name=password", "Value={PasswordParameter}", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		"Name=login.x", "Value=50", ENDITEM, 
		"Name=login.y", "Value=8", ENDITEM, 
		LAST);

	lr_end_transaction("TicketPurchase_01_LogIn",LR_AUTO);

	lr_think_time(29);

	lr_start_transaction("TicketPurchase_02_SelectFlightsButton");

	web_image("Search Flights Button", 
		"Alt=Search Flights Button", 
		"Snapshot=t3.inf", 
		LAST);

	lr_end_transaction("TicketPurchase_02_SelectFlightsButton",LR_AUTO);

	lr_think_time(29);

	lr_start_transaction("TicketPurchase_03_FindFlight");

	web_submit_form("reservations.pl", 
		"Snapshot=t4.inf", 
		ITEMDATA, 
		"Name=depart", "Value=Portland", ENDITEM, 
		"Name=departDate", "Value=04/29/2021", ENDITEM, 
		"Name=arrive", "Value=San Francisco", ENDITEM, 
		"Name=returnDate", "Value=04/30/2021", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=roundtrip", "Value=<OFF>", ENDITEM, 
		"Name=seatPref", "Value=Aisle", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=findFlights.x", "Value=45", ENDITEM, 
		"Name=findFlights.y", "Value=8", ENDITEM, 
		LAST);

	lr_end_transaction("TicketPurchase_03_FindFlight",LR_AUTO);

	lr_think_time(20);

	lr_start_transaction("TicketPurchase_04_SelectFlight");

	web_submit_form("reservations.pl_2", 
		"Snapshot=t5.inf", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=563;62;04/29/2021", ENDITEM, 
		"Name=reserveFlights.x", "Value=53", ENDITEM, 
		"Name=reserveFlights.y", "Value=11", ENDITEM, 
		LAST);

	lr_end_transaction("TicketPurchase_04_SelectFlight",LR_AUTO);

	lr_start_transaction("TicketPurchase_05_PaymentDetails");

	web_reg_find("Text=Thank you for booking through Web Tours.", 
		LAST);

	lr_think_time(42);

	web_submit_form("reservations.pl_3", 
		"Snapshot=t6.inf", 
		ITEMDATA, 
		"Name=firstName", "Value=Jojo", ENDITEM, 
		"Name=lastName", "Value=Bean", ENDITEM, 
		"Name=address1", "Value=nope streel", ENDITEM, 
		"Name=address2", "Value=bangkok", ENDITEM, 
		"Name=pass1", "Value=Jojo Bean", ENDITEM, 
		"Name=creditCard", "Value=54545121548541548", ENDITEM, 
		"Name=expDate", "Value=10/24", ENDITEM, 
		"Name=saveCC", "Value=on", ENDITEM, 
		"Name=buyFlights.x", "Value=28", ENDITEM, 
		"Name=buyFlights.y", "Value=7", ENDITEM, 
		LAST);

	lr_end_transaction("TicketPurchase_05_PaymentDetails",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("TicketPurchase_06_SignOff");

	web_image("SignOff Button", 
		"Alt=SignOff Button", 
		"Ordinal=1", 
		"Snapshot=t7.inf", 
		LAST);

	lr_end_transaction("TicketPurchase_06_SignOff",LR_AUTO);

	return 0;
}